function StartAProjectButton() {
  return (
    <div className="-translate-x-1/2 absolute bg-white border border-black border-solid h-[54.391px] left-[calc(50%+0.5px)] rounded-[12px] top-[251.19px] w-[172.758px]" data-name="Start a Project button">
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Roboto:Medium',sans-serif] font-medium justify-center leading-[0] left-[84.88px] text-[23.4px] text-black text-center top-[25.81px] tracking-[-1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[35.84px]">Start a Project</p>
      </div>
    </div>
  );
}

function HeaderWithStartProjectButton() {
  return (
    <div className="absolute h-[401.578px] left-0 right-0 top-[70px]" data-name="Header with start project button" style={{ backgroundImage: "linear-gradient(168.427deg, rgb(255, 255, 255) 0%, rgb(226, 232, 240) 100%)" }}>
      <StartAProjectButton />
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Roboto:ExtraBold',sans-serif] font-extrabold justify-center leading-[0] left-[calc(50%+0.5px)] text-[#34c759] text-[71.4px] text-center top-[calc(50%-35.79px)] tracking-[-1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="mb-0">
          <span className="leading-[35.84px]">{`Creative `}</span>
          <span className="leading-[35.84px] text-[#08f]">Solutions.</span>
        </p>
        <p className="leading-[35.84px]">&nbsp;</p>
      </div>
      <div className="-translate-x-1/2 -translate-y-1/2 absolute flex flex-col font-['Roboto:ExtraBold',sans-serif] font-extrabold justify-center leading-[0] left-1/2 text-[30.4px] text-black text-center top-[calc(50%+0.21px)] tracking-[-1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <p className="leading-[35.84px]">We build digital experiences that people actually love to use.</p>
      </div>
    </div>
  );
}

function StrategyServiceCard() {
  return (
    <div className="absolute bg-white h-[161.133px] left-0 right-[68.06%] rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] top-0" data-name="Strategy service card">
      <p className="absolute font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] left-[8.15%] right-[8.15%] text-[16px] top-[71.95px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        We define the path to success before we even touch a pixel.
      </p>
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[29.952px] left-[8.16%] right-[74.11%] text-[18.72px] top-[42.42px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Strategy
      </p>
    </div>
  );
}

function UxDesignServiceCard() {
  return (
    <div className="absolute bg-white h-[161.133px] left-[34.03%] right-[34.03%] rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] top-0" data-name="UX Design service card">
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[29.952px] left-[8.15%] right-[74.12%] text-[18.72px] top-[39.77px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        UX Design
      </p>
      <p className="absolute font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] left-[8.15%] right-[19.5%] text-[16px] top-[69.9px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Interfaces built for humans, not just for machines.
      </p>
    </div>
  );
}

function DevelopmentServiceCard() {
  return (
    <div className="absolute bg-white h-[161.133px] left-[68.06%] right-0 rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] top-0" data-name="Development service card">
      <p className="absolute font-['Roboto:Bold',sans-serif] font-bold leading-[29.952px] left-[8.15%] right-[69.23%] text-[18.72px] top-[39.77px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Development
      </p>
      <p className="absolute font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] left-[8.15%] right-[8.15%] text-[16px] top-[71.95px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        Clean, high-performance code that scales with your growth.
      </p>
    </div>
  );
}

function ServiceCardsGridContainer() {
  return (
    <div className="absolute h-[161.133px] left-[10%] right-[10%] text-[#1e293b] top-[535.58px]" data-name="Service cards grid container">
      <StrategyServiceCard />
      <UxDesignServiceCard />
      <DevelopmentServiceCard />
    </div>
  );
}

function FooterCopyrightSection() {
  return (
    <div className="absolute bg-black h-[121.594px] left-0 opacity-90 right-0 top-[760.71px]" data-name="Footer copyright section">
      <p className="absolute font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] left-[42.71%] right-[42.55%] text-[16px] text-white top-[47.95px]" style={{ fontVariationSettings: "'wdth' 100" }}>
        © 2026 Brand Design. Always Elevating.
      </p>
    </div>
  );
}

function ServicesNavigationLink() {
  return (
    <div className="col-1 h-[25.594px] ml-[75px] mt-0 relative row-1 w-[58.992px]" data-name="Services navigation link">
      <p className="absolute font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] left-0 right-[-5.1%] text-[16px] text-black top-[-0.05px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Services
      </p>
    </div>
  );
}

function PortfolioNavigationLink() {
  return (
    <div className="col-1 h-[25.594px] ml-[165.99px] mt-0 relative row-1 w-[63.516px]" data-name="Portfolio navigation link">
      <p className="absolute font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] left-0 right-[0.81%] text-[16px] text-black top-[-0.05px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Portfolio
      </p>
    </div>
  );
}

function ContactNavigationLink() {
  return (
    <div className="col-1 h-[25.594px] ml-0 mt-0 relative row-1 w-[56.266px]" data-name="Contact navigation link">
      <p className="absolute font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] left-0 right-[-1.31%] text-[16px] text-black top-[-0.05px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Contact
      </p>
    </div>
  );
}

function Group() {
  return (
    <div className="col-1 grid-cols-[max-content] grid-rows-[max-content] inline-grid ml-[261.51px] mt-0 place-items-start relative row-1">
      <ContactNavigationLink />
    </div>
  );
}

function Group1() {
  return (
    <div className="grid-cols-[max-content] grid-rows-[max-content] inline-grid leading-[0] place-items-start relative shrink-0">
      <p className="col-1 font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] ml-0 mt-0 relative row-1 text-[16px] text-black whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        Home
      </p>
      <ServicesNavigationLink />
      <PortfolioNavigationLink />
      <Group />
    </div>
  );
}

function NavigationLinksList() {
  return (
    <div className="content-stretch flex h-[25.594px] items-start relative shrink-0 w-[318.766px]" data-name="Navigation links list">
      <Group1 />
    </div>
  );
}

function NavigationBarWithLogoAndLinks() {
  return (
    <div className="absolute bg-white content-stretch flex h-[70px] items-center justify-between left-0 pb-[17.086px] pt-[17.078px] px-[192px] right-0 shadow-[0px_2px_10px_0px_rgba(0,0,0,0.05)] top-0" data-name="Navigation bar with logo and links">
      <p className="font-['Roboto:ExtraBold',sans-serif] font-extrabold leading-[0] relative shrink-0 text-[#6366f1] text-[22.4px] tracking-[-1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <span className="leading-[35.84px] text-[#34c759]">Brand</span>
        <span className="leading-[35.84px]">{` `}</span>
        <span className="leading-[35.84px] text-[#08f]">Design</span>
      </p>
      <NavigationLinksList />
    </div>
  );
}

export default function BrandDesignModernResponsive() {
  return (
    <div className="bg-[#f8fafc] relative size-full" data-name="Brand Design | Modern & Responsive">
      <HeaderWithStartProjectButton />
      <ServiceCardsGridContainer />
      <FooterCopyrightSection />
      <NavigationBarWithLogoAndLinks />
    </div>
  );
}