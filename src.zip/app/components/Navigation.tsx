import { Link, useLocation } from 'react-router';

export function Navigation() {
  const location = useLocation();
  
  const isActive = (path: string) => {
    return location.pathname === path;
  };

  return (
    <nav className="absolute bg-white content-stretch flex h-[70px] items-center justify-between left-0 pb-[17.086px] pt-[17.078px] px-4 md:px-12 lg:px-[192px] right-0 shadow-[0px_2px_10px_0px_rgba(0,0,0,0.05)] top-0 z-50" data-name="Navigation bar with logo and links">
      <Link to="/" className="font-['Roboto:ExtraBold',sans-serif] font-extrabold leading-[0] relative shrink-0 text-[#6366f1] text-[22.4px] tracking-[-1px] whitespace-nowrap" style={{ fontVariationSettings: "'wdth' 100" }}>
        <span className="leading-[35.84px] text-[#34c759]">Brand</span>
        <span className="leading-[35.84px]">{` `}</span>
        <span className="leading-[35.84px] text-[#08f]">Design</span>
      </Link>
      
      <div className="content-stretch flex items-start gap-4 md:gap-[50px] lg:gap-[75px]" data-name="Navigation links list">
        <Link 
          to="/" 
          className={`font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] text-[16px] ${isActive('/') ? 'text-[#34c759]' : 'text-black'} hover:text-[#34c759] transition-colors whitespace-nowrap`}
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Home
        </Link>
        <Link 
          to="/services" 
          className={`font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] text-[16px] ${isActive('/services') ? 'text-[#34c759]' : 'text-black'} hover:text-[#34c759] transition-colors whitespace-nowrap`}
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Services
        </Link>
        <Link 
          to="/portfolio" 
          className={`font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] text-[16px] ${isActive('/portfolio') ? 'text-[#34c759]' : 'text-black'} hover:text-[#34c759] transition-colors whitespace-nowrap`}
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Portfolio
        </Link>
        <Link 
          to="/contact" 
          className={`font-['Roboto:Medium',sans-serif] font-medium leading-[25.6px] text-[16px] ${isActive('/contact') ? 'text-[#34c759]' : 'text-black'} hover:text-[#34c759] transition-colors whitespace-nowrap`}
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Contact
        </Link>
      </div>
    </nav>
  );
}
