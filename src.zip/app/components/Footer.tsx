export function Footer() {
  return (
    <footer className="bg-black opacity-90 py-12" data-name="Footer copyright section">
      <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] text-[16px] text-white text-center" style={{ fontVariationSettings: "'wdth' 100" }}>
        © 2026 Brand Design. Always Elevating.
      </p>
    </footer>
  );
}
