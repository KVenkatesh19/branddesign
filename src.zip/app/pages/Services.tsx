import { Check } from 'lucide-react';

export function Services() {
  const services = [
    {
      title: 'Strategy',
      description: 'We define the path to success before we even touch a pixel.',
      features: [
        'Market Research & Analysis',
        'Competitive Positioning',
        'Brand Strategy Development',
        'User Research & Insights',
        'Digital Transformation Planning'
      ],
      color: '#34c759'
    },
    {
      title: 'UX Design',
      description: 'Interfaces built for humans, not just for machines.',
      features: [
        'User Experience Design',
        'User Interface Design',
        'Wireframing & Prototyping',
        'Usability Testing',
        'Design Systems & Style Guides'
      ],
      color: '#08f'
    },
    {
      title: 'Development',
      description: 'Clean, high-performance code that scales with your growth.',
      features: [
        'Web Application Development',
        'Mobile App Development',
        'E-commerce Solutions',
        'API Integration',
        'Performance Optimization'
      ],
      color: '#6366f1'
    }
  ];

  return (
    <div className="px-4 md:px-12 lg:px-[10%] py-16">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-[40px] md:text-[56px] tracking-[-1px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
          <span className="text-[#34c759]">Our </span>
          <span className="text-[#08f]">Services</span>
        </h1>
        <p className="font-['Roboto:Regular',sans-serif] font-normal text-[18px] max-w-3xl mx-auto text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
          We offer comprehensive digital solutions to help your business thrive in the modern world.
        </p>
      </div>

      {/* Services Grid */}
      <div className="space-y-12">
        {services.map((service, index) => (
          <div 
            key={index}
            className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.05)] p-8 md:p-12"
          >
            <div className="flex items-start gap-6 mb-6">
              <div 
                className="w-16 h-16 rounded-full flex items-center justify-center text-white font-['Roboto:ExtraBold',sans-serif] font-extrabold text-[24px]"
                style={{ backgroundColor: service.color, fontVariationSettings: "'wdth' 100" }}
              >
                {index + 1}
              </div>
              <div>
                <h2 
                  className="font-['Roboto:Bold',sans-serif] font-bold text-[28px] mb-2"
                  style={{ color: service.color, fontVariationSettings: "'wdth' 100" }}
                >
                  {service.title}
                </h2>
                <p className="font-['Roboto:Regular',sans-serif] font-normal text-[18px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                  {service.description}
                </p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
              {service.features.map((feature, featureIndex) => (
                <div key={featureIndex} className="flex items-center gap-3">
                  <Check className="w-5 h-5 flex-shrink-0" style={{ color: service.color }} />
                  <span className="font-['Roboto:Regular',sans-serif] font-normal text-[16px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    {feature}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
