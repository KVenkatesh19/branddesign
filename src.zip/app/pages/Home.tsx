import { Link } from 'react-router';

export function Home() {
  return (
    <div>
      {/* Header Section */}
      <section 
        className="relative h-[400px] md:h-[500px] flex flex-col items-center justify-center px-4" 
        style={{ backgroundImage: "linear-gradient(168.427deg, rgb(255, 255, 255) 0%, rgb(226, 232, 240) 100%)" }}
      >
        <h1 className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-center text-[40px] md:text-[56px] lg:text-[71.4px] tracking-[-1px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
          <span className="text-[#34c759]">Creative </span>
          <span className="text-[#08f]">Solutions.</span>
        </h1>
        <p className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-center text-[20px] md:text-[24px] lg:text-[30.4px] tracking-[-1px] text-black mb-8 max-w-4xl" style={{ fontVariationSettings: "'wdth' 100" }}>
          We build digital experiences that people actually love to use.
        </p>
        <Link 
          to="/contact"
          className="bg-white border border-black border-solid rounded-[12px] px-8 py-4 font-['Roboto:Medium',sans-serif] font-medium text-[20px] md:text-[23.4px] text-black text-center tracking-[-1px] hover:bg-black hover:text-white transition-colors"
          style={{ fontVariationSettings: "'wdth' 100" }}
        >
          Start a Project
        </Link>
      </section>

      {/* Services Section */}
      <section className="px-4 md:px-12 lg:px-[10%] py-16">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {/* Strategy Card */}
          <div className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] p-8">
            <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[18.72px] text-[#1e293b] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
              Strategy
            </h3>
            <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] text-[16px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
              We define the path to success before we even touch a pixel.
            </p>
          </div>

          {/* UX Design Card */}
          <div className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] p-8">
            <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[18.72px] text-[#1e293b] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
              UX Design
            </h3>
            <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] text-[16px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
              Interfaces built for humans, not just for machines.
            </p>
          </div>

          {/* Development Card */}
          <div className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.03)] p-8">
            <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[18.72px] text-[#1e293b] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
              Development
            </h3>
            <p className="font-['Roboto:Regular',sans-serif] font-normal leading-[25.6px] text-[16px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
              Clean, high-performance code that scales with your growth.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
