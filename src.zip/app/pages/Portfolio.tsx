import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { ExternalLink, Github, Code2 } from 'lucide-react';

export function Portfolio() {
  const projects = [
    {
      title: 'E-Commerce Platform',
      category: 'Development & UX Design',
      description: 'A modern e-commerce solution with seamless checkout and inventory management.',
      color: '#34c759',
      techStack: ['React', 'Node.js', 'PostgreSQL', 'Stripe'],
      githubUrl: 'https://github.com/branddesign/ecommerce-platform',
      liveUrl: 'https://ecommerce-demo.branddesign.com'
    },
    {
      title: 'Healthcare App',
      category: 'Mobile App & Strategy',
      description: 'Patient management system connecting healthcare providers with patients.',
      color: '#08f',
      techStack: ['React Native', 'Firebase', 'Express', 'MongoDB'],
      githubUrl: 'https://github.com/branddesign/healthcare-app',
      liveUrl: 'https://healthcare-demo.branddesign.com'
    },
    {
      title: 'Financial Dashboard',
      category: 'UX Design & Development',
      description: 'Real-time analytics and reporting dashboard for financial institutions.',
      color: '#6366f1',
      techStack: ['Next.js', 'TypeScript', 'Recharts', 'Redis'],
      githubUrl: 'https://github.com/branddesign/financial-dashboard',
      liveUrl: 'https://finance-demo.branddesign.com'
    },
    {
      title: 'Social Media Platform',
      category: 'Full Stack Development',
      description: 'Community-driven platform with real-time messaging and content sharing.',
      color: '#34c759',
      techStack: ['React', 'GraphQL', 'WebSocket', 'AWS'],
      githubUrl: 'https://github.com/branddesign/social-platform',
      liveUrl: 'https://social-demo.branddesign.com'
    },
    {
      title: 'Education Portal',
      category: 'Strategy & Development',
      description: 'Online learning platform with interactive courses and progress tracking.',
      color: '#08f',
      techStack: ['Vue.js', 'Django', 'PostgreSQL', 'S3'],
      githubUrl: 'https://github.com/branddesign/education-portal',
      liveUrl: 'https://edu-demo.branddesign.com'
    },
    {
      title: 'Restaurant Management',
      category: 'Mobile & Web App',
      description: 'All-in-one solution for reservations, orders, and kitchen management.',
      color: '#6366f1',
      techStack: ['React', 'Node.js', 'MySQL', 'Twilio'],
      githubUrl: 'https://github.com/branddesign/restaurant-management',
      liveUrl: 'https://restaurant-demo.branddesign.com'
    }
  ];

  return (
    <div className="px-4 md:px-12 lg:px-[10%] py-16">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-[40px] md:text-[56px] tracking-[-1px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
          <span className="text-[#34c759]">Our </span>
          <span className="text-[#08f]">Portfolio</span>
        </h1>
        <p className="font-['Roboto:Regular',sans-serif] font-normal text-[18px] max-w-3xl mx-auto text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Explore our recent projects and see how we've helped businesses transform their digital presence.
        </p>
      </div>

      {/* Portfolio Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {projects.map((project, index) => (
          <div 
            key={index}
            className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.05)] overflow-hidden group hover:shadow-[0px_15px_40px_0px_rgba(0,0,0,0.1)] transition-shadow"
          >
            {/* Image Placeholder */}
            <div 
              className="h-48 flex items-center justify-center relative"
              style={{ backgroundColor: project.color }}
            >
              <div className="absolute inset-0 bg-black opacity-0 group-hover:opacity-10 transition-opacity" />
              <span className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-white text-[48px] opacity-20" style={{ fontVariationSettings: "'wdth' 100" }}>
                {index + 1}
              </span>
            </div>
            
            {/* Content */}
            <div className="p-6">
              <div className="flex items-start justify-between mb-2">
                <h3 
                  className="font-['Roboto:Bold',sans-serif] font-bold text-[20px]"
                  style={{ color: project.color, fontVariationSettings: "'wdth' 100" }}
                >
                  {project.title}
                </h3>
              </div>
              <p className="font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#64748b] mb-3" style={{ fontVariationSettings: "'wdth' 100" }}>
                {project.category}
              </p>
              <p className="font-['Roboto:Regular',sans-serif] font-normal text-[16px] text-[#1e293b] leading-[24px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
                {project.description}
              </p>

              {/* Tech Stack */}
              <div className="flex flex-wrap gap-2 mb-4">
                {project.techStack.map((tech, techIndex) => (
                  <span
                    key={techIndex}
                    className="px-3 py-1 bg-[#f1f5f9] rounded-full font-['Roboto:Medium',sans-serif] font-medium text-[12px] text-[#64748b]"
                    style={{ fontVariationSettings: "'wdth' 100" }}
                  >
                    {tech}
                  </span>
                ))}
              </div>

              {/* Links */}
              <div className="flex gap-3">
                <a
                  href={project.githubUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 border border-[#e2e8f0] rounded-lg hover:border-[#1e293b] transition-colors"
                >
                  <Github className="w-4 h-4" />
                  <span className="font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Code
                  </span>
                </a>
                <a
                  href={project.liveUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 flex items-center justify-center gap-2 px-4 py-2 rounded-lg text-white hover:opacity-90 transition-opacity"
                  style={{ backgroundColor: project.color }}
                >
                  <ExternalLink className="w-4 h-4" />
                  <span className="font-['Roboto:Medium',sans-serif] font-medium text-[14px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Live
                  </span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}