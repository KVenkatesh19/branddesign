import { useState } from 'react';
import { Mail, Phone, MapPin, Send } from 'lucide-react';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    company: '',
    message: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission (mock for now)
    alert('Thank you for your message! We will get back to you soon.');
    setFormData({ name: '', email: '', company: '', message: '' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  return (
    <div className="px-4 md:px-12 lg:px-[10%] py-16">
      {/* Header */}
      <div className="text-center mb-16">
        <h1 className="font-['Roboto:ExtraBold',sans-serif] font-extrabold text-[40px] md:text-[56px] tracking-[-1px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
          <span className="text-[#34c759]">Get in </span>
          <span className="text-[#08f]">Touch</span>
        </h1>
        <p className="font-['Roboto:Regular',sans-serif] font-normal text-[18px] max-w-3xl mx-auto text-[#1e293b]" style={{ fontVariationSettings: "'wdth' 100" }}>
          Ready to start your project? Let's discuss how we can help bring your vision to life.
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Contact Information */}
        <div className="space-y-8">
          <div className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.05)] p-8">
            <h2 className="font-['Roboto:Bold',sans-serif] font-bold text-[24px] text-[#1e293b] mb-6" style={{ fontVariationSettings: "'wdth' 100" }}>
              Contact Information
            </h2>
            
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#34c759] flex items-center justify-center flex-shrink-0">
                  <Mail className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[16px] text-[#1e293b] mb-1" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Email
                  </h3>
                  <p className="font-['Roboto:Regular',sans-serif] font-normal text-[16px] text-[#64748b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    hello@branddesign.com
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#08f] flex items-center justify-center flex-shrink-0">
                  <Phone className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[16px] text-[#1e293b] mb-1" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Phone
                  </h3>
                  <p className="font-['Roboto:Regular',sans-serif] font-normal text-[16px] text-[#64748b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    +1 (555) 123-4567
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-[#6366f1] flex items-center justify-center flex-shrink-0">
                  <MapPin className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="font-['Roboto:Bold',sans-serif] font-bold text-[16px] text-[#1e293b] mb-1" style={{ fontVariationSettings: "'wdth' 100" }}>
                    Location
                  </h3>
                  <p className="font-['Roboto:Regular',sans-serif] font-normal text-[16px] text-[#64748b]" style={{ fontVariationSettings: "'wdth' 100" }}>
                    123 Creative Street, Design City, DC 12345
                  </p>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-br from-[#34c759] to-[#08f] rounded-[20px] p-8 text-white">
            <h2 className="font-['Roboto:Bold',sans-serif] font-bold text-[24px] mb-4" style={{ fontVariationSettings: "'wdth' 100" }}>
              Why Work With Us?
            </h2>
            <ul className="space-y-3">
              <li className="font-['Roboto:Regular',sans-serif] font-normal text-[16px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                ✓ 10+ years of industry experience
              </li>
              <li className="font-['Roboto:Regular',sans-serif] font-normal text-[16px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                ✓ 200+ successful projects delivered
              </li>
              <li className="font-['Roboto:Regular',sans-serif] font-normal text-[16px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                ✓ Dedicated support team
              </li>
              <li className="font-['Roboto:Regular',sans-serif] font-normal text-[16px]" style={{ fontVariationSettings: "'wdth' 100" }}>
                ✓ Flexible engagement models
              </li>
            </ul>
          </div>
        </div>

        {/* Contact Form */}
        <div className="bg-white rounded-[20px] shadow-[0px_10px_30px_0px_rgba(0,0,0,0.05)] p-8">
          <h2 className="font-['Roboto:Bold',sans-serif] font-bold text-[24px] text-[#1e293b] mb-6" style={{ fontVariationSettings: "'wdth' 100" }}>
            Send us a Message
          </h2>
          
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#1e293b] mb-2" style={{ fontVariationSettings: "'wdth' 100" }}>
                Full Name *
              </label>
              <input
                type="text"
                name="name"
                required
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-[#e2e8f0] rounded-lg font-['Roboto:Regular',sans-serif] font-normal text-[16px] focus:outline-none focus:border-[#34c759] transition-colors"
                placeholder="John Doe"
              />
            </div>

            <div>
              <label className="block font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#1e293b] mb-2" style={{ fontVariationSettings: "'wdth' 100" }}>
                Email Address *
              </label>
              <input
                type="email"
                name="email"
                required
                value={formData.email}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-[#e2e8f0] rounded-lg font-['Roboto:Regular',sans-serif] font-normal text-[16px] focus:outline-none focus:border-[#34c759] transition-colors"
                placeholder="john@example.com"
              />
            </div>

            <div>
              <label className="block font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#1e293b] mb-2" style={{ fontVariationSettings: "'wdth' 100" }}>
                Company
              </label>
              <input
                type="text"
                name="company"
                value={formData.company}
                onChange={handleChange}
                className="w-full px-4 py-3 border border-[#e2e8f0] rounded-lg font-['Roboto:Regular',sans-serif] font-normal text-[16px] focus:outline-none focus:border-[#34c759] transition-colors"
                placeholder="Your Company"
              />
            </div>

            <div>
              <label className="block font-['Roboto:Medium',sans-serif] font-medium text-[14px] text-[#1e293b] mb-2" style={{ fontVariationSettings: "'wdth' 100" }}>
                Message *
              </label>
              <textarea
                name="message"
                required
                value={formData.message}
                onChange={handleChange}
                rows={5}
                className="w-full px-4 py-3 border border-[#e2e8f0] rounded-lg font-['Roboto:Regular',sans-serif] font-normal text-[16px] focus:outline-none focus:border-[#34c759] transition-colors resize-none"
                placeholder="Tell us about your project..."
              />
            </div>

            <button
              type="submit"
              className="w-full bg-[#34c759] text-white py-4 rounded-lg font-['Roboto:Bold',sans-serif] font-bold text-[18px] hover:bg-[#2da849] transition-colors flex items-center justify-center gap-2"
              style={{ fontVariationSettings: "'wdth' 100" }}
            >
              Send Message
              <Send className="w-5 h-5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
